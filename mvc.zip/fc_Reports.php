<?php 
require_once('./class_Reports.php');

$oReports = new Reports();

$action = isset($_POST['action']) ? $_POST['action'] : isset($_GET['action']) ? $_GET['action'] : null;
// $action = "getNewClients";

switch($action){
    case "getNewClients":
        header("Content-type:text/html");
        echo $oReports->getNewClients();
    break;
    case "getLostClients":
        header("Content-type:text/html");
        echo $oReports->getLostClients();
    break;
    case "getNewEmployees":
        header("Content-type:text/html");
        echo $oReports->getNewEmployees();
    break;
    case "getLostEmployees":
        header("Content-type:text/html");
        echo $oReports->getLostEmployees();
    break;
    case "getSalesDistribution":
        header("Content-type:text/html");
        echo $oReports->getSalesDistribution();
    break;
    case "getIndustry":
        header("Content-type:text/html");
        echo $oReports->getIndustry();
    break;
    case "getCountry":
        header("Content-type:text/html");
        echo $oReports->getCountry();
    break;
    case "getCollection":
        header("Content-type:text/html");
        echo $oReports->getCollection();
    break;
}