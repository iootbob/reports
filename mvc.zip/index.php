<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
 
</head>

<style>
  	body
  	{
  		font-family: "Nirmala UI", helvetica, sans-serif;
  		margin: 0; 
  		padding: 0;
  		color: #464646
  	}
  	.title_icon
  	{
  		width: 45px;float: left;margin: 0px 15px 0px 15px
  	}
  	.table_container
  	{
  		width: 90%;background-color: #ffffff;
  		border: 1px solid #c8c8c8;
  	}
  	.table_title_container
  	{
  		height:90px;
  		width: 100%;
  		background: linear-gradient(to bottom right, #39a395,#94dffc);
  		padding-top:45px;
  		padding-left: 10px;
  		margin-bottom: 0;
  	}
  	.table_title
  	{
  		font-size:35px;
  		margin:0px;
  		font-family: "Nirmala UI", helvetica;
  		font-weight: 100;
  		color: #ffffff;
  		padding-top: 5px;
  		padding-left: 15px
  	}
  	.table_cell
  	{
  		border: 1px solid #c8c8c8;
  		text-align: center;
  	}
  	.currency
    {
        text-align: right;
    }
</style>

<body style="background-color:#e6e6e6">

    <div id="reports">
		<div>
			<table align="center" border="0" cellpadding="0" cellspacing="0" width="1320" style="border:0;">
				<tbody>
					<tr style="height: 40px;">
						<td style="width: 40px"></td>
						<td></td>
						<td style="width: 40px"></td>
					</tr>
					<tr>
						<td></td>
						<td align="center" bgcolor="" style="height:300px;background: linear-gradient(to bottom , #1f3e6c,#48b2a3);border-top-left-radius: 30px;border-top-right-radius: 30px">
							<img src="cid:pb_cropped" style="width: 60px;">
							<p style="font-size:40px;margin:0px;font-family: ' . 'Arial Black'.', Arial;font-weight: 800;color: #ffffff">MANAGEMENT REPORTS</p>
							<p style="color: #ffffff;margin: 0px;">As of 6 August, 2018 1:42 PM</p>
						</td>
						<td></td>
					</tr>
				</tbody>
			</table>
		</div>
    </div>

     
    <script src="./node_modules/jquery/dist/jquery.min.js"></script>
    <script type="text/javascript">
     
	
	let reports = {
		ajaxSetup : function(){
			$.ajaxSetup(function(){
				cache: true
			});
		},
		getNewClients : function(){
			setTimeout(function(){
				$.ajax({
				url : "./fc_Reports.php?action=getNewClients",
				cache: false,
				type : "GET",
				// contentType : "text/html"
			}).done(function(res){
				$("#reports").append(res); 
				console.log(res);
			})
			},10);
		},
		getLostClients : function(){

			setTimeout(function(){
				$.ajax({
				url : "./fc_Reports.php?action=getLostClients",
				cache: false,
				type : "GET",
				// contentType : "text/html"
			}).done(function(res){
				$("#reports").append(res); 
			})
			},20);
		},
		getNewEmployees : function(){
			
			setTimeout(function(){
				$.ajax({
				url : "./fc_Reports.php?action=getNewEmployees",
				cache: false,
				type : "GET",
				// contentType : "text/html"
			}).done(function(res){
				$("#reports").append(res); 
			})
			},30);
		},
		getLostEmployees : function(){
			
			setTimeout(function(){
				$.ajax({
				url : "./fc_Reports.php?action=getLostEmployees",
				cache: false,
				type : "GET",
				// contentType : "text/html"
			}).done(function(res){
				$("#reports").append(res); 
			})
			},40);
		},
		getSalesDistribution : function(){
			
			setTimeout(function(){
				$.ajax({
				url : "./fc_Reports.php?action=getSalesDistribution",
				cache: false,
				type : "GET",
				// contentType : "text/html"
			}).done(function(res){
				$("#reports").append(res); 
			})
			},50);
		},
		getIndustry : function(){
			
			setTimeout(function(){
				$.ajax({
				url : "./fc_Reports.php?action=getIndustry",
				cache: false,
				type : "GET",
				// contentType : "text/html"
			}).done(function(res){
				$("#reports").append(res); 
			})
			},60);
		},
		getCountry : function(){

			setTimeout(function(){
				$.ajax({
				url : "./fc_Reports.php?action=getCountry",
				cache: false,
				type : "GET",
				// contentType : "text/html"
			}).done(function(res){
				$("#reports").append(res); 
			})
			},70);
		},
		getCollection : function(){

			setTimeout(function(){
				$.ajax({
				url : "./fc_Reports.php?action=getCollection",
				cache: false,
				type : "GET",
				// contentType : "text/html"
			}).done(function(res){
				$("#reports").append(res); 
			})
			},80);
		},
		sendEmail : function(){
			// let styleHtml = document.getElementsByTagName('style')[0];
			let style = `<!DOCTYPE html><html><head> <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /><style type="text/css">${$("style").html()}</style></head>`;
			let content = "<body style='background-color: #e6e6e6;'>" + $("#reports").html() + "</body></html>" ;

			$.ajax({
				url : "./mail.php",
				type : "POST",
				data : {html : style + content}
			}) 
		}
		,
		init : function(){
			let reports_array = [
				this.getNewClients(),
				this.getLostClients(),
				this.getNewEmployees(),
				this.getLostEmployees(),
				this.getSalesDistribution(),
				this.getIndustry(),
				this.getCountry(),
				this.getCollection()
				];

			$.when(...reports_array).then(function(){
				// reports.sendEmail();
				
				setTimeout(function(){
					this.sendEmail();
					// console.log($("#reports").html());
				}.bind(this) ,2000);
			}.bind(this));

		}
	}

	reports.init();

     

    </script>
</body>
</html>