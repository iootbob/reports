<?php 
require_once("./DB.php");

// $w = new Reports();
// $w->getLostEmployees();

class Reports{

    public static $array = [
        ["id" => 1, "name" => "Philip", "lname", "lname" => "Rosales"],
        ["id" => 2, "name" => "John", "lname" => "Doe"]
    ];

    private $_dbConn;

    public function __construct(){
        $this->_dbConn = DB::getInstance();
    }

    public function getNewClients(){

        $query = "SELECT _created_at,client_name,contract_type,mrr,contract_expire_date 
        FROM clients 
        WHERE _created_at >= :first_day
        AND _created_at <= :last_day 
        AND active = 1 
        ORDER BY _created_at DESC";

        $stmnt = $this->_dbConn->prepare($query);
        $stmnt->bindValue(":first_day",date("Y-m-01"));
        $stmnt->bindValue(":last_day",date("Y-m-t"));
        $stmnt->execute();
        
        return $this->_renderNewClientsToHtml($stmnt);

    }

    public function _renderNewClientsToHtml($data){

        $html = "";

        $html = '<div>
                    <table align="center" border="0" cellpadding="0" cellspacing="0" width="1320" style="border:0;">
                        <tbody>
                            <tr>
                                <td style="width: 40px"></td>
                                <td></td>
                                <td style="width: 40px"></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td bgcolor="#ffffff">
                                <div style="margin: 10px;">
                                        <table style="width: 100%; overflow: hidden;" cellspacing="0" cellpadding="0">
                                            <tbody>
                                                <tr style="padding: 0">
                                                    <td>
                                                        <div class="table_title_container">
                                                            <img class="title_icon" src="cid:new_client" style="">
                                                            <p class="table_title" style="">New Clients</p>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr >
                                                    <td style="border: 1px solid #c8c8c8;border-top: 0;padding: 20px 0px 20px 0px;">
                                                        <table align="center" border="0" cellpadding="10" cellspacing="0" class="table_container">
                                                            <thead>
                                                                <tr style="background-color: #F0F0F0">
                                                                    <th colspan="6" class="table_cell">June</th>
                                                                </tr>
                                                                <tr style="background-color: #F0F0F0">
                                                                    <th class="table_cell">Date Signed</th>
                                                                    <th class="table_cell">Client</th>
                                                                    <th class="table_cell">Type of Contract</th>
                                                                    <th class="table_cell">MRR</th>
                                                                    <th class="table_cell">Contract Expiration</th>
                                                                    
                                                                </tr>
                                                            </thead>
                                                            <tbody>';

                                            while($row = $data->fetch(PDO::FETCH_ASSOC)){
                                                
                                                $html .= '<tr>
                                                            <td class="table_cell">'. date("F d, Y",strtotime($row['_created_at'])).'</td>
                                                            <td class="table_cell">'. $row['client_name'] .'</td>
                                                            <td class="table_cell">'. $row['contract_type'] .'</td>
                                                            <td class="currency table_cell">'. $row['mrr'] .'</td>
                                                            <td class="table_cell">'. date("F d, Y",strtotime($row['contract_expire_date'])) .'</td>
                                                            
                                                        </tr>';
                                            }

                                                $html.='</tbody>
                                                        <tfoot style="background-color: #F0F0F0">
                                                            <th class="table_cell" colspan="3">Total</th>
                                                            <th class="currency table_cell"></th>
                                                            <th class="table_cell"></th>
                                                            
                                                        </tfoot>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </td> 
                            </tr>
                        </tbody>
                    </table>
                </div>';

        return $html;

    }

    public function getLostClients(){

        $return_array = self::$array;
        return $this->_renderLostClientsToHtml($return_array);

    }

    public function _renderLostClientsToHtml($data){

        $html = "";

        $html = '<div>
                    <table align="center" border="0" cellpadding="0" cellspacing="0" width="1320" style="border:0;">
                        <tbody>
                            <tr>
                                <td style="width: 40px"></td>
                                <td></td>
                                <td style="width: 40px"></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td bgcolor="#ffffff">
                                <div style="margin: 10px;">
                                        <table style="width: 100%; overflow: hidden;" cellspacing="0" cellpadding="0">
                                            <tbody>
                                                <tr style="padding: 0">
                                                    <td>
                                                        <div class="table_title_container">
                                                            <img class="title_icon" src="cid:client_lost" style="">
                                                            <p class="table_title" style="">Lost Clients</p>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr >
                                                    <td style="border: 1px solid #c8c8c8;border-top: 0;padding: 20px 0px 20px 0px;">
                                                        <table align="center" border="0" cellpadding="10" cellspacing="0" class="table_container">
                                                            <thead>
                                                                <tr style="background-color: #F0F0F0">
                                                                    <th colspan="6" class="table_cell">June</th>
                                                                </tr>
                                                                <tr>
                                                                    <th class="table_cell">Separation Date</th>
                                                                    <th class="table_cell">Client</th>
                                                                    <th class="table_cell">Type of Contract</th>
                                                                    <th class="table_cell">MRR</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>';

                                            foreach($data as $ar){
                                                
                                                $html .= '<tr>
                                                            <td class="table_cell">August 2, 2018</td>
                                                            <td class="table_cell">Momentum</td>
                                                            <td class="table_cell">OSA</td>
                                                            <td class="currency table_cell">25,800.00</td>
                                                        </tr>';
                                            }

                                                $html.='</tbody>
                                                        <tfoot style="background-color: #F0F0F0">
                                                        <tr>
                                                            <th class="table_cell" colspan="3">Total</th>
                                                            <th class="currency table_cell">33,800.00</th>
                                                        </tr>
                                                        </tfoot>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </td> 
                            </tr>
                        </tbody>
                    </table>
                </div>';

        return $html;
        
    }

    public function getNewEmployees(){

        // $return_array = self::$array;
        $query = "SELECT emp.first_name,emp.last_name,emp.current_position,emp.reporting_line,emp.hire_date,cli.client_name 
        FROM employees AS emp
        JOIN clients AS cli ON emp.client_id = cli.client_id
        WHERE emp.hire_date >= :first_day 
        AND emp.hire_date <= :last_day 
        AND emp.seat_contract_type = 'MSA' 
        AND NOT emp.employment_status = :emp_status 
        AND NOT emp.client_id = 1 ";

        $stmnt = $this->_dbConn->prepare($query);
        $stmnt->bindValue(":first_day",date("Y-m-01"));
        $stmnt->bindValue(":last_day",date("Y-m-t"));
        $stmnt->bindValue(":emp_status","RESIGNED");
        $stmnt->execute();
         
        return $this->_renderNewEmployeesToHtml($stmnt);

    }

    public function _renderNewEmployeesToHtml($data){

        $html = "";

        $html = '<div>
                    <table align="center" border="0" cellpadding="0" cellspacing="0" width="1320" style="border:0;">
                        <tbody>
                            <tr>
                                <td style="width: 40px"></td>
                                <td></td>
                                <td style="width: 40px"></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td bgcolor="#ffffff">
                                <div style="margin: 10px;">
                                        <table style="width: 100%; overflow: hidden;" cellspacing="0" cellpadding="0">
                                            <tbody>
                                                <tr style="padding: 0">
                                                    <td>
                                                        <div class="table_title_container">
                                                            <img class="title_icon" src="cid:new_employee" style="">
                                                            <p class="table_title" style="">New Employees</p>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr >
                                                    <td style="border: 1px solid #c8c8c8;border-top: 0;padding: 20px 0px 20px 0px;">
                                                        <table align="center" border="0" cellpadding="10" cellspacing="0" class="table_container">
                                                            <thead>
                                                                <tr>
                                                                    <th class="table_cell">Name</th>
                                                                    <th class="table_cell">Position Title</th>
                                                                    <th class="table_cell">Immediate Supervisor</th>
                                                                    <th class="table_cell">Onboarding Date</th>
                                                                    <th class="table_cell">Company</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>';

                                            while($row = $data->fetch(PDO::FETCH_ASSOC)){
                                                
                                                $html .= '<tr>
                                                            <td class="table_cell">'.$row['first_name'].' '.$row['last_name'].'</td>
                                                            <td class="table_cell">'. $row['current_position'] .'</td>
                                                            <td class="table_cell">'. $row['reporting_line'] .'</td>
                                                            <td class="table_cell">'. date("F d, Y",strtotime($row['hire_date'])) .'</td>
                                                            <td class="table_cell">'. $row['client_name'] .'</td>
                                                        </tr>';
                                            }

                                                $html.='</tbody>
                                                       
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </td> 
                            </tr>
                        </tbody>
                    </table>
                </div>';

        return $html;
        
    }

    public function getLostEmployees(){

        $return_array = self::$array;

        $query = "SELECT separation_date
        FROM employees
        WHERE separation_date >= :first_day
        AND separation_date <= :last_day
        AND seat_contract_type = 'MSA'
        AND employment_status = 'RESIGNED'";

        $stmnt = $this->_dbConn->prepare($query);
        $stmnt->bindValue(":first_day",date("Y-05-01"));
        $stmnt->bindValue(":last_day",date("Y-05-t"));

        $stmnt->execute();
        echo "<pre>",print_r($stmnt->fetchAll()),"</pre>";

        return $this->_renderLostEmployeesToHtml($return_array);

    }

    public function _renderLostEmployeesToHtml($data){

        $html = "";

        $html = '<div>
                    <table align="center" border="0" cellpadding="0" cellspacing="0" width="1320" style="border:0;">
                        <tbody>
                            <tr>
                                <td style="width: 40px"></td>
                                <td></td>
                                <td style="width: 40px"></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td bgcolor="#ffffff">
                                <div style="margin: 10px;">
                                        <table style="width: 100%; overflow: hidden;" cellspacing="0" cellpadding="0">
                                            <tbody>
                                                <tr style="padding: 0">
                                                    <td>
                                                        <div class="table_title_container">
                                                            <img class="title_icon" src="cid:new_employee" style="">
                                                            <p class="table_title" style="">Lost Employees</p>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr >
                                                    <td style="border: 1px solid #c8c8c8;border-top: 0;padding: 20px 0px 20px 0px;">
                                                        <table align="center" border="0" cellpadding="10" cellspacing="0" class="table_container">
                                                            <thead>
                                                                <tr>
                                                                    <th  class="table_cell">Name</th>
                                                                    <th class="table_cell">Position Title</th>
                                                                    <th class="table_cell">Immediate Supervisor</th>
                                                                    <th class="table_cell">Separation Date</th>
                                                                    <th class="table_cell">Company</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>';

                                            foreach($data as $ar){
                                                
                                                $html .= '<tr>
                                                            <td class="table_cell">Kiervin Guinto</td>
                                                            <td class="table_cell">Finance Associate</td>
                                                            <td class="table_cell">Finance Manager</td>
                                                            <td class="table_cell">August 23, 2018</td>
                                                            <td class="table_cell">Penbrothers</td>
                                                          </tr>';
                                            }
                                                $html.='</tbody>             
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </td> 
                            </tr>
                        </tbody>
                    </table>
                </div>';

        return $html;
        
    }

    public function getSalesDistribution(){

        $return_array = self::$array;
        return $this->_renderSalesDistributionToHtml($return_array);

    }

    public function _renderSalesDistributionToHtml($data){

        $html = "";

        $html = '<div>
                    <table align="center" border="0" cellpadding="0" cellspacing="0" width="1320" style="border:0;">
                        <tbody>
                            <tr>
                                <td style="width: 40px"></td>
                                <td></td>
                                <td style="width: 40px"></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td bgcolor="#ffffff">
                                <div style="margin: 10px;">
                                        <table style="width: 100%; overflow: hidden;" cellspacing="0" cellpadding="0">
                                            <tbody>
                                                <tr style="padding: 0">
                                                    <td>
                                                        <div class="table_title_container">
                                                            <img class="title_icon" src="cid:client_price_range " style="">
                                                            <p class="table_title" style="">Active Clients Sales Distribution</p>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr >
                                                    <td style="border: 1px solid #c8c8c8;border-top: 0;padding: 20px 0px 20px 0px;">
                                                        <table align="center" border="0" cellpadding="10" cellspacing="0" class="table_container">
                                                            <thead>
                                                                <tr>
                                                                    <th class="table_cell">Price Range</th>
                                                                    <th class="table_cell">MSA</th>
                                                                    <th class="table_cell">OSA</th>
                                                                    <th class="table_cell">MRR</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>';

                                            foreach($data as $ar){
                                                
                                                $html .= '<tr>
                                                            <td class="table_cell">0.00-10,000.00</td>
                                                            <td class="table_cell">4</td>
                                                            <td class="table_cell">10</td>
                                                            <td class="currency table_cell">140,000.00</td>
                                                          </tr>';
                                            }

                                                $html.='</tbody>
                                                        <tfoot style="background-color: #F0F0F0">
                                                            <tr>
                                                                <th class="table_cell">Total</th>
                                                                <th class="table_cell">38</th>
                                                                <th class="table_cell">65</th>
                                                                <th class="currency table_cell">5,520,000.00</th>
                                                            </tr>
                                                        </tfoot>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </td> 
                            </tr>
                        </tbody>
                    </table>
                </div>';

        return $html;
        
    }

    public function getIndustry(){

        $return_array = self::$array;
        return $this->_renderIndustryToHtml($return_array);

    }

    public function _renderIndustryToHtml($data){

        $html = "";

        $html = '<div>
                    <table align="center" border="0" cellpadding="0" cellspacing="0" width="1320" style="border:0;">
                        <tbody>
                            <tr>
                                <td style="width: 40px"></td>
                                <td></td>
                                <td style="width: 40px"></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td bgcolor="#ffffff">
                                <div style="margin: 10px;">
                                        <table style="width: 100%; overflow: hidden;" cellspacing="0" cellpadding="0">
                                            <tbody>
                                                <tr style="padding: 0">
                                                    <td>
                                                        <div class="table_title_container">
                                                            <img class="title_icon" src="cid:client_info" style="">
                                                            <p class="table_title" style="">Client / Employee by Industry</p>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr >
                                                    <td style="border: 1px solid #c8c8c8;border-top: 0;padding: 20px 0px 20px 0px;">
                                                        <table align="center" border="0" cellpadding="10" cellspacing="0" class="table_container">
                                                            <thead>
                                                                <tr>
                                                                    <th class="table_cell">Industry</th>
                                                                    <th class="table_cell">No. of Clients</th>
                                                                    <th class="table_cell">No. of Employees</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>';

                                            foreach($data as $ar){
                                                
                                                $html .= '<tr>
                                                            <td class="table_cell">E-commerce</td>
                                                            <td class="table_cell">8</td>
                                                            <td class="table_cell">37</td>     
                                                        </tr>';
                                            }

                                                $html.='</tbody>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </td> 
                            </tr>
                        </tbody>
                    </table>
                </div>';

        return $html;
        
    }

    public function getCountry(){

        $return_array = self::$array;
        return $this->_renderCountryToHtml($return_array);

    }

    public function _renderCountryToHtml($data){

        $html = "";

        $html = '<div>
                    <table align="center" border="0" cellpadding="0" cellspacing="0" width="1320" style="border:0;">
                        <tbody>
                            <tr>
                                <td style="width: 40px"></td>
                                <td></td>
                                <td style="width: 40px"></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td bgcolor="#ffffff">
                                <div style="margin: 10px;">
                                        <table style="width: 100%; overflow: hidden;" cellspacing="0" cellpadding="0">
                                            <tbody>
                                                <tr style="padding: 0">
                                                    <td>
                                                        <div class="table_title_container">
                                                            <img class="title_icon" src="cid:client_revenue" style="">
                                                            <p class="table_title" style="">Clients Revenue by Country</p>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr >
                                                    <td style="border: 1px solid #c8c8c8;border-top: 0;padding: 20px 0px 20px 0px;">
                                                        <table align="center" border="0" cellpadding="10" cellspacing="0" class="table_container">
                                                            <thead>
                                                                <tr>
                                                                    <th class="table_cell">Country</th>
                                                                    <th class="table_cell">No. of Clients</th>
                                                                    <th class="table_cell">MRR</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>';

                                            foreach($data as $ar){
                                                
                                                $html .= '<tr>
                                                            <td class="table_cell">Philippines</td>
                                                            <td class="table_cell">32</td>
                                                            <td class="currency table_cell">3,000,000.00</td>
                                                        </tr>';
                                            }

                                                $html.='</tbody>
                                                        <tfoot style="background-color: #F0F0F0">
                                                            <tr>
                                                                <th class="table_cell" colspan="2">Total</th>
                                                                <th class="currency table_cell">5,520,000.00</th>
                                                            </tr>
                                                        </tfoot>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </td> 
                            </tr>
                        </tbody>
                    </table>
                </div>';

        return $html;
        
    }

    public function getCollection(){

        $return_array = self::$array;
        return $this->_renderCollectionToHtml($return_array);

    }

    public function _renderCollectionToHtml($data){

        $html = "";

        $html = '<div>
                    <table align="center" border="0" cellpadding="0" cellspacing="0" width="1320" style="border:0;">
                        <tbody>
                            <tr>
                                <td style="width: 40px"></td>
                                <td></td>
                                <td style="width: 40px"></td>
                            </tr>
                            <tr>
                                <td></td>
                                <td bgcolor="#ffffff">
                                <div style="margin: 10px;">
                                        <table style="width: 100%; overflow: hidden;" cellspacing="0" cellpadding="0">
                                            <tbody>
                                                <tr style="padding: 0">
                                                    <td>
                                                        <div class="table_title_container">
                                                            <img class="title_icon" src="cid:collection" style="">
                                                            <p class="table_title" style="">Collections</p>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <tr >
                                                    <td style="border: 1px solid #c8c8c8;border-top: 0;padding: 20px 0px 20px 0px;">
                                                        <table align="center" border="0" cellpadding="10" cellspacing="0" class="table_container">
                                                            <thead>
                                                                <tr style="background-color: #F0F0F0">
                                                                    <th class="table_cell">Office</th>
                                                                    <th class="table_cell">Client Name</th>
                                                                    <th class="table_cell">Invoice Amount</th>      
                                                                    <th class="table_cell">Status</th>
                                                                    <th class="table_cell">Pct</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>';

                                            foreach($data as $ar){
                                                
                                                $html .= '<tr>
                                                            <td class="table_cell">OPL 4</td>
                                                            <td class="table_cell">Client 1</td>
                                                            <td class="table_cell currency">200,000.00</td>
                                                            <td class="table_cell">Paid</td>
                                                            <td class="table_cell">10%</td>
                                                        </tr>';
                                            }

                                                $html.='</tbody>
                                                        </table>
                                                        <table align="center" border="0" cellpadding="10" cellspacing="0" style="margin-top: 20px;" class="table_container">
                                                            <thead>
                                                                <tr style="background-color: #F0F0F0"> 
                                                                    <th class="table_cell">Office</th>
                                                                    <th class="table_cell">Total Invoiced</th>
                                                                    <th class="table_cell">Collected</th>      
                                                                    <th class="table_cell">Receivable</th>
                                                                </tr>
                                                            </thead>
                                                            <tbody>
                                                                <tr>
                                                                    <td class="table_cell">OPL 4</td>
                                                                    <td class="currency table_cell">600,000.00</td>
                                                                    <td class="currency table_cell">400,000.00</td>
                                                                    <td class="currency table_cell">200,000.00</td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="table_cell">OPL 5</td>
                                                                    <td class="currency table_cell">600,000.00</td>
                                                                    <td class="currency table_cell">400,000.00</td>
                                                                    <td class="currency table_cell">200,000.00</td>
                                                                </tr>
                                                                <tr>
                                                                    <td class="table_cell">OPL 6</td>
                                                                    <td class="currency table_cell">600,000.00</td>
                                                                    <td class="currency table_cell">400,000.00</td>
                                                                    <td class="currency table_cell">200,000.00</td>
                                                                </tr>
                                                            </tbody>
                                                            <tfoot style="background-color: #F0F0F0">
                                                                <tr>
                                                                    <th class="table_cell">Total</th>
                                                                    <th class="currency table_cell">1,800,000.00</th>
                                                                    <th class="currency table_cell">1,200,000.00</th>
                                                                    <th class="currency table_cell">600,000.00</th>
                                                                </tr>    
                                                            </tfoot>
                                                        </table>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </td> 
                            </tr>
                        </tbody>
                    </table>
                </div>';

        return $html;
        
    }


}